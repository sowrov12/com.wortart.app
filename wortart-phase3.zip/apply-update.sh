#!/usr/bin/env bash
# Run once from the repository root after unzipping the update, then commit.
# It removes the files that this update replaced, so old code does not stay behind and
# break the build. The script deletes itself when it is done.
set -e

OBSOLETE=(
  "app/src/main/java/com/wortart/app/ui/flashcard/FlashcardDeck.kt"
  "app/src/androidTest/java/com/wortart/app/ui/flashcard/ChoiceFlowTest.kt"
)

for file in "${OBSOLETE[@]}"; do
  if [ -f "$file" ]; then
    rm -f "$file"
    echo "removed $file"
  fi
done

echo "Done. Now run: git add -A && git commit -m \"Phase 2\" && git push"
rm -- "$0"
